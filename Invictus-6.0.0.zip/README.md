![Invictus Resource Pack](/BRAND/Invictus_hero_dark.png?raw=true)


_Crisp contemporary Minecraft graphics_
 

## Credits
Derived from [Soar49's 169 public domain Soartex textures](http://www.minecraftforum.net/topic/150915-).  
All known Soar49 assets [have been collected here](https://github.com/InvictusGraphics/Soartex_Originals).  

Thanks to GoldBattle, SenyaHitomi and Brayden Houston for their contributions.   
I welcome pull requests (or even issues with .zips), but reserve the right to be selective.  


#### Official Links
- [Soartex.net](http://soartex.net)
- [CurseForge](https://minecraft.curseforge.com/projects/invictus-vanilla)
- [Github Repository](https://github.com/InvictusGraphics/Invictus_Textures)
